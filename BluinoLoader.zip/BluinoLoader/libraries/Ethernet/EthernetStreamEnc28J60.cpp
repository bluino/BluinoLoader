/*
  EthernetStreamEnc28J60.cpp - Streaming Ethernet Arduino library for Enc28J60-based ethernet shield
  Copyright (c) 2012 Anton Smirnov (dev@antonsmirnov.name)
	
	TODO : implement (please, contribute)
*/

/******************************************************************************
 * Includes
 ******************************************************************************/

#include <EthernetStreamEnc28J60.h>
#include <Arduino.h>

/******************************************************************************
 * Definitions
 ******************************************************************************/

 /*
int EthernetStream::begin(uint8_t *mac_address, uint16_t port)
{
	// TODO : implement
}

void EthernetStream::begin(uint8_t *mac_address, IPAddress local_ip, uint16_t port)
{
	// TODO : implement
}

IPAddress EthernetStream::localIP()
{
	// TODO : implement
}

int EthernetStream::available()
{
	// TODO : implement
}

int EthernetStream::read()
{
	// TODO : implement
}

void EthernetStream::flush() {
	// TODO : implement
}

int EthernetStream::peek() {
	// TODO : implement
}

size_t EthernetStream::write(uint8_t outcomingByte) {	
	// TODO : implement
}

*/